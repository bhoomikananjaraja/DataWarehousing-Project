    #Install pymongo using pip, the package installer for Python.
    #pip install pymongo

    #Import the pymongo package to connect to MongoDB server
    #Import datetime package to handle the datetime formatting of date values
import pymongo 
from datetime import datetime

    # Import time package to measure the performance in terms of time
    # Import the psutil library for system and process utilities
import time
import psutil

    # Import pandas to read csv files
import pandas as pd

    # Import the 'resource' module from Python's standard library
    # This module is used for querying and controlling system resources utilized by the program
    # It is particularly useful for measuring resource usage (like CPU time and memory consumption) of the program
import resource

def load_mongo():
    #Connect to the MongoDB database with the default localhost and port number  
    myclient = pymongo.MongoClient("mongodb://localhost:27017/")

    # Create/Select 'Online_Retail_Sales' database
    mydb = myclient["Retail_Sales"]


    # 1) Customers Collection 

    # Define the collection name
    collection_name = "customers"

    # Start the timer to measure the time taken for the operation
    start_time = time.time()

    # Specify the path to the CSV file
    csv_file_path = "/Users/bhoomikan/Desktop/Datawarehousing/29/customers_data.csv"

    # Read the CSV file into a Pandas DataFrame
    df = pd.read_csv(csv_file_path)

    # Convert the 'CustomerID' column to string type
    df['CustomerID'] = df["CustomerID"].astype('string')

    # Convert 'CustomerSince' and 'Date_of_Birth' columns to datetime objects
    df['CustomerSince'] = pd.to_datetime(df['CustomerSince'], format='%Y-%m-%d')
    df['Date_of_Birth'] = pd.to_datetime(df['Date_of_Birth'], format='%Y-%m-%d')

    # Print the DataFrame information to check data types and non-null counts
    #print(df.info())

    # Convert the DataFrame to a dictionary format for insertion into MongoDB
    data = df.to_dict(orient='records')

    # Select or create the collection in the database
    collection = mydb[collection_name]

    # Reset the start time for the MongoDB operation
    start_time = time.time()

    # Insert the data into the collection
    collection.insert_many(data)

    # Record the end time of the operation
    end_time = time.time()

    # Print the time taken to insert the data
    print("Time taken to insert data:", end_time - start_time, "seconds")

    # Print a confirmation message indicating successful data loading
    print(f"Data from {csv_file_path} loaded into MongoDB collection '{collection_name}'.")
    # Measure CPU utilization
    # 'psutil.cpu_percent' gives the system-wide CPU utilization as a percentage
    # 'interval' parameter is set to the duration of the data loading process
    # 'end_time - start_time' calculates the duration of the MongoDB insert operation
    cpu_utilization = psutil.cpu_percent(interval=end_time - start_time)

    # Print the CPU utilization during the MongoDB data load operation
    print(f"CPU Utilization during query execution: {cpu_utilization}%")


    # 2) Products Collection
    # Define the collection name for products
    collection_name = "products"

    # Start the timer to measure the time taken for the operation
    start_time = time.time()

    # Specify the path to the products CSV file
    csv_file_path = "/Users/bhoomikan/Desktop/Datawarehousing/29/products_data.csv"

    # Read the CSV file into a Pandas DataFrame
    df = pd.read_csv(csv_file_path)

    # Print rows where 'Product_Created' column has null values
    #print(df[df['Product_Created'].isnull()])   # Checking for null values in 'Product_Created'

    # Drop rows with any null values
    df = df.dropna()

    # Print DataFrame information after dropping null values
    #print(df.info())

    # Define the date format for 'Product_Created' and 'Product_lastUpdated' columns
    date_format = "%m/%d/%y %H:%M"

    # Convert 'Product_Created' and 'Product_lastUpdated' columns to datetime objects
    df['Product_Created'] = pd.to_datetime(df['Product_Created'], format='%Y-%m-%d')
    df['Product_lastUpdated'] = pd.to_datetime(df['Product_lastUpdated'], format='%Y-%m-%d')

    # Print DataFrame information to verify the data types after conversion
    #print(df.info())

    # Convert StockCode in products to upper case
    df['StockCode'] = df['StockCode'].str.upper()

    # Convert the DataFrame to a dictionary format for insertion into MongoDB
    data = df.to_dict(orient='records')

    # Select or create the collection in the database
    collection = mydb[collection_name]

    # Reset the start time for the MongoDB operation
    start_time = time.time()

    # Insert the processed data into the 'products' collection
    collection.insert_many(data)

    # Record the end time of the operation
    end_time = time.time()

    # Print the time taken to insert the data
    print("Time taken to insert data:", end_time - start_time, "seconds")

    # Print a confirmation message indicating successful data loading
    print(f"Data from {csv_file_path} loaded into MongoDB collection '{collection_name}'.")
    # Measure CPU utilization
    # 'psutil.cpu_percent' gives the system-wide CPU utilization as a percentage
    # 'interval' parameter is set to the duration of the data loading process
    # 'end_time - start_time' calculates the duration of the MongoDB insert operation
    cpu_utilization = psutil.cpu_percent(interval=end_time - start_time)

    # Print the CPU utilization during the MongoDB data load operation
    print(f"CPU Utilization during query execution: {cpu_utilization}%")


    # 3) Orders Collection
    # Define the collection name for orders
    collection_name = "orders"

    # Start the timer to measure the time taken for the operation
    start_time = time.time()

    # Specify the path to the orders CSV file
    csv_file_path = "/Users/bhoomikan/Desktop/Datawarehousing/29/orders_data.csv"

    # Read the CSV file into a Pandas DataFrame
    df = pd.read_csv(csv_file_path)

    # Print DataFrame information (data types, non-null counts)
    #print(df.info())

    # Print rows where 'CustomerID' column has null values
    #print(df[df['CustomerID'].isna()])

    # Replace the null value at a specific row and column with a default CustomerID
    df.iloc[3301, df.columns.get_loc('CustomerID')] = '17850'  # Filling null value at row 3301

    # Convert 'CustomerID' column first to integer and then to string type
    df['CustomerID'] = df["CustomerID"].astype('int')
    df['CustomerID'] = df["CustomerID"].astype('string')

    # Define the date format for 'InvoiceDate' column
    date_format = "%m/%d/%y %H:%M"

    # Convert 'InvoiceDate' column to datetime objects
    df['InvoiceDate'] = pd.to_datetime(df['InvoiceDate'], format=date_format)

    # Print DataFrame information to verify the data types after conversion
    #print(df.info())

    # Convert the DataFrame to a dictionary format for insertion into MongoDB
    data = df.to_dict(orient='records')

    # Select or create the collection in the database
    collection = mydb[collection_name]

    # Reset the start time for the MongoDB operation
    start_time = time.time()

    # Insert the processed data into the 'orders' collection
    collection.insert_many(data)

    # Record the end time of the operation
    end_time = time.time()

    # Print the time taken to insert the data
    print("Time taken to insert data:", end_time - start_time, "seconds")

    # Print a confirmation message indicating successful data loading
    print(f"Data from {csv_file_path} loaded into MongoDB collection '{collection_name}'.")
    # Measure CPU utilization
    # 'psutil.cpu_percent' gives the system-wide CPU utilization as a percentage
    # 'interval' parameter is set to the duration of the data loading process
    # 'end_time - start_time' calculates the duration of the MongoDB insert operation
    cpu_utilization = psutil.cpu_percent(interval=end_time - start_time)

    # Print the CPU utilization during the MongoDB data load operation
    print(f"CPU Utilization during query execution: {cpu_utilization}%")


    # 4) Reviews Collection
    # Define the collection name for reviews
    collection_name = "reviews"

    # Start the timer to measure the time taken for the operation
    start_time = time.time()

    # Specify the path to the reviews CSV file
    csv_file_path = "/Users/bhoomikan/Desktop/Datawarehousing/29/reviewsdata.csv"

    # Read the CSV file into a Pandas DataFrame
    df = pd.read_csv(csv_file_path)

    # Print DataFrame information (data types, non-null counts)
    #print(df.info())

    # Convert the DataFrame to a dictionary format for insertion into MongoDB
    data = df.to_dict(orient='records')

    # Select or create the collection in the database
    collection = mydb[collection_name]

    # Reset the start time for the MongoDB operation
    start_time = time.time()

    # Insert the processed data into the 'reviews' collection
    collection.insert_many(data)

    # Record the end time of the operation
    end_time = time.time()

    # Print the time taken to insert the data
    print("Time taken to insert data:", end_time - start_time, "seconds")

    # Print a confirmation message indicating successful data loading
    print(f"Data from {csv_file_path} loaded into MongoDB collection '{collection_name}'.")
    # Measure CPU utilization
    # 'psutil.cpu_percent' gives the system-wide CPU utilization as a percentage
    # 'interval' parameter is set to the duration of the data loading process
    # 'end_time - start_time' calculates the duration of the MongoDB insert operation
    cpu_utilization = psutil.cpu_percent(interval=end_time - start_time)

    # Print the CPU utilization during the MongoDB data load operation
    print(f"CPU Utilization during query execution: {cpu_utilization}%")


    # 5) Transactions Table
    # Define the collection name for transactions
    collection_name = "transactions"

    # Start the timer to measure the time taken for the operation
    start_time = time.time()

    # Specify the path to the transactions CSV file
    csv_file_path = "/Users/bhoomikan/Desktop/Datawarehousing/29/transactions_data.csv"

    # Read the CSV file into a Pandas DataFrame
    df = pd.read_csv(csv_file_path)

    # Print DataFrame information (data types, non-null counts)
    #print(df.info())

    # Convert 'CustomerID' column to string type
    df['CustomerID'] = df["CustomerID"].astype('string')

    # Define the date format for 'InvoiceDate' column
    date_format = "%m/%d/%y %H:%M"

    # Convert 'InvoiceDate' column to datetime objects
    df['InvoiceDate'] = pd.to_datetime(df['InvoiceDate'], format=date_format)

    # Print DataFrame information to verify the data types after conversion
    #print(df.info())

    # Convert StockCode in products to upper case
    df['StockCode'] = df['StockCode'].str.upper()

    # Convert the DataFrame to a dictionary format for insertion into MongoDB
    data = df.to_dict(orient='records')

    # Select or create the collection in the database
    collection = mydb[collection_name]

    # Reset the start time for the MongoDB operation
    start_time = time.time()

    # Insert the processed data into the 'transactions' collection
    collection.insert_many(data)

    # Record the end time of the operation
    end_time = time.time()

    # Print the time taken to insert the data
    print("Time taken to insert data:", end_time - start_time, "seconds") 

    # Print a confirmation message indicating successful data loading
    print(f"Data from {csv_file_path} loaded into MongoDB collection '{collection_name}'.")
    # Measure CPU utilization
    # 'psutil.cpu_percent' gives the system-wide CPU utilization as a percentage
    # 'interval' parameter is set to the duration of the data loading process
    # 'end_time - start_time' calculates the duration of the MongoDB insert operation
    cpu_utilization = psutil.cpu_percent(interval=end_time - start_time)

    # Print the CPU utilization during the MongoDB data load operation
    print(f"CPU Utilization during query execution: {cpu_utilization}%")


    #Create Individual objects for each collection in the database ('Online_Retail_Sales'),
    #to access the data from these collections
    transactions = mydb['transactions']
    orders = mydb['orders']
    products = mydb['products']
    customers = mydb['customers']
    reviews = mydb['reviews']

    #Check for the initialization of database 
    #print(mydb)

    #Check whether instances for each collection is created or not
    #print(transactions)
    #print(orders)
    #print(products)
    #print(customers)
    #print(reviews)

    # 1) Average Ratings for each product
    # Define the aggregation pipeline to compute average ratings for each product
    pipeline_1 = [
        {
            '$group': {
                '_id': '$StockCode',
                'Ratings_Avg': {'$avg': '$ratings'}
            }
        },
        {
            '$sort': {'Ratings_Avg': -1}
        }
    ]

    # Record the start time and resource usage before executing the query
    start_time = time.time()
    start_resources = resource.getrusage(resource.RUSAGE_SELF)

    # Execute the aggregation pipeline
    result = list(reviews.aggregate(pipeline_1))

    # Record the end time and resource usage after executing the query
    end_time = time.time()
    end_resources = resource.getrusage(resource.RUSAGE_SELF)

    # Calculate the time taken and resource utilization
    time_taken = end_time - start_time
    cpu_time_used = end_resources.ru_utime - start_resources.ru_utime  
    memory_used = end_resources.ru_maxrss - start_resources.ru_maxrss  

    # Print the result of the aggregation
    #for doc in result:
    #    print(doc)

    #print(len(result))

    # Print the time taken and resource utilization
    print(f"Time taken for query execution: {time_taken} seconds")
    print(f"CPU time used: {cpu_time_used} seconds")
    print(f"Memory used: {memory_used} kilobytes")


    # Comment explaining the context and purpose of the query
    '''
    In the context of data validation and query testing, we have identified a need to simulate a 
    scenario involving missing products. To achieve this, we are intentionally deleting certain rows 
    from the 'transactions' collection. This action serves a dual purpose: firstly, to validate the 
    correctness and efficiency of the delete operation itself, and secondly, to assess the system's 
    response to data resembling a real-world scenario where some products might be missing.

    The specific operation executed here targets the deletion of all documents within the 'transactions' 
    collection that have a 'StockCode' corresponding to one of the following values: '15034', '15044A', 
    or '15044C'. These stock codes have been selected for this exercise based on predefined criteria 
    relevant to our testing objectives. The deletion process's effectiveness and the time taken to 
    complete the operation will be closely monitored and analyzed to ensure optimal query performance 
    and to understand the impact of such operations on our overall data integrity and system functionality.
    '''

    # Start measuring time and resource usage
    start_time = time.time()
    start_resources = resource.getrusage(resource.RUSAGE_SELF)

    # MongoDB query to delete specific documents
    deletion_filter = {'StockCode': {'$in': ['22752','22749','22310']}} 
    result = transactions.delete_many(deletion_filter)

    # Stop measuring time and resource usage
    end_time = time.time()
    end_resources = resource.getrusage(resource.RUSAGE_SELF)

    # Calculate the time taken and resource utilization
    time_taken = end_time - start_time
    cpu_time_used = end_resources.ru_utime - start_resources.ru_utime 
    memory_used = end_resources.ru_maxrss - start_resources.ru_maxrss  

    # Print the result of the deletion
    print(f"Documents deleted: {result.deleted_count}")

    # Print the time taken and resource utilization
    print(f"Time taken for deletion operation: {time_taken} seconds")
    print(f"CPU time used: {cpu_time_used} seconds")
    #print(f"Memory used: {memory_used} kilobytes")


    # 2) Products that are never sold till date
    # Define the aggregation pipeline
    pipeline_2 = [
        {
            '$lookup': {
                'from': 'transactions',         # Join with the 'transactions' collection
                'localField': 'StockCode',      # Field from the 'products' collection
                'foreignField': 'StockCode',    # Field from the 'transactions' collection
                'as': 'sold_items'              # Output array containing joined documents
            }
        },
        {
            '$match': {
                'sold_items': []                # Filter to keep products with no matching sold items
            }
        },
        {
            '$project': {
                'StockCode': 1,                 # Include the StockCode in the output
                '_id': 0                        # Exclude the '_id' field
            }
        }
    ]

    # Record the start time and resource usage before executing the query
    start_time = time.time()
    start_resources = resource.getrusage(resource.RUSAGE_SELF)

    # Execute the aggregation pipeline
    result = list(products.aggregate(pipeline_2))

    # Record the end time and resource usage after executing the query
    end_time = time.time()
    end_resources = resource.getrusage(resource.RUSAGE_SELF)

    # Calculate the time taken and resource utilization
    time_taken = end_time - start_time
    cpu_time_used = end_resources.ru_utime - start_resources.ru_utime
    memory_used = end_resources.ru_maxrss - start_resources.ru_maxrss

    # Print the result of the aggregation
    #for doc in result:
    #    print(doc)

    # Print the time taken and resource utilization
    print(f"Time taken for query execution: {time_taken} seconds")
    print(f"CPU time used: {cpu_time_used} seconds")
    #print(f"Memory used: {memory_used} kilobytes")


    # 3) How far had it been since the last purchase by a customer (in terms of days)
    # Set the current date and time
    current_date = datetime.now()

    # Define the aggregation pipeline for the calculation
    pipeline_3 = [
        {
            '$group': {
                '_id': '$CustomerID',                      # Group by CustomerID
                'MaxInvoiceDate': {'$max': '$InvoiceDate'} # Find the latest InvoiceDate for each customer
            }
        },
        {
            '$addFields': {
                'Diff_days': {
                    '$subtract': [current_date, '$MaxInvoiceDate'] # Calculate the difference in time from the last purchase
                }
            }
        },
        {
            '$addFields': {
                'Diff_days': {
                    '$divide': ['$Diff_days', 1000 * 60 * 60 * 24] # Convert the difference from milliseconds to days
                }
            }
        },
        {
            '$addFields': {
                'Diff_days': {
                    '$toInt': '$Diff_days' # Convert the days difference to an integer
                }
            }
        },
        {
            '$match': {
                'Diff_days': {'$gt': 90} # Filter customers who haven't purchased in the last 90 days
            }
        },
        {
            '$sort': {'Diff_days': -1}         # Sort the results in descending order by count
        },
        {
            '$project': {
                'CustomerID': '$_id', # Project the CustomerID and Diff_days
                'Diff_days': 1,
                '_id': 0
            }
        }
    ]

    # Measure the time and resources used by the query
    start_time = time.time()
    start_resources = resource.getrusage(resource.RUSAGE_SELF)

    # Execute the aggregation pipeline
    result = list(transactions.aggregate(pipeline_3))

    end_time = time.time()
    end_resources = resource.getrusage(resource.RUSAGE_SELF)

    # Calculate the time taken and resource utilization
    time_taken = end_time - start_time
    cpu_time_used = end_resources.ru_utime - start_resources.ru_utime
    memory_used = end_resources.ru_maxrss - start_resources.ru_maxrss


    # Print the results of the query
    #for doc in result:
    #    print(doc)

    # Print the time taken and resource utilization
    print(f"Time taken for query execution: {time_taken} seconds")
    print(f"CPU time used: {cpu_time_used} seconds")
    print(f"Memory used: {memory_used} kilobytes")


    # 4) Most preffered payment mode
    # Define the aggregation pipeline
    pipeline_4 = [
        {
            '$group': {
                '_id': '$PaymentMode',                  # Group by PaymentMode
                'Popular_Paymodes': {'$sum': 1}        # Count occurrences of each PaymentMode
            }
        },
        {
            '$sort': {'Popular_Paymodes': -1}         # Sort the results in descending order by count
        },
        {
            '$limit': 10                              # Limit the result to the top 10 entries
        },
        {
            '$project': {
                'PaymentMode': '$_id',                # Project the PaymentMode and count
                'Popular_Paymodes': 1,
                '_id': 0                              # Exclude the '_id' field
            }
        }
    ]

    # Measure the time and resources used by the query
    start_time = time.time()
    start_resources = resource.getrusage(resource.RUSAGE_SELF)

    # Execute the aggregation pipeline
    result = list(orders.aggregate(pipeline_4))

    end_time = time.time()
    end_resources = resource.getrusage(resource.RUSAGE_SELF)

    # Calculate the time taken and resource utilization
    time_taken = end_time - start_time
    cpu_time_used = end_resources.ru_utime - start_resources.ru_utime
    memory_used = end_resources.ru_maxrss - start_resources.ru_maxrss

    # Print the results of the query
    #for doc in result:
    #    print(doc)

    # Print the time taken and resource utilization
    print(f"Time taken for query execution: {time_taken} seconds")
    print(f"CPU time used: {cpu_time_used} seconds")
    print(f"Memory used: {memory_used} kilobytes")


    # 5) Top 10 most sold products
    # Define an aggregation pipeline 
    pipeline_5 = [
        {
            # Group documents by 'StockCode'
            '$group': {
                '_id': '$StockCode',  # 'StockCode' is used as the grouping key
                'Quantity_Sold': {'$sum': 1}  # Count the number of sales (documents) for each 'StockCode'
            }
        },
        {
            # Sort the results in descending order by 'Quantity_Sold'
            '$sort': {'Quantity_Sold': -1}
        },
        {
            # Limit the results to the top 10
            '$limit': 10
        },
        {
            # Join with the 'products' collection to include additional product details
            '$lookup': {
                'from': products.name,  # Specify the collection to join with ('products')
                'localField': '_id',    # Field from the transactions documents ('StockCode')
                'foreignField': 'StockCode',  # Corresponding field in the 'products' collection
                'as': 'product_info'    # Output array for the joined product information
            }
        },
        {
            # Unwind the 'product_info' array to separate documents
            '$unwind': '$product_info'
        },
        {
            # Select specific fields for the final output
            '$project': {
                'StockCode': '$_id',  # Include 'StockCode'
                'Quantity_Sold': 1,   # Include 'Quantity_Sold'
                # Include relevant details from the 'product_info' join
                'Description': '$product_info.Description',
                'UnitPrice': '$product_info.UnitPrice',
                'Ratings': '$product_info.Ratings',
                'QuantityAvailable': '$product_info.QuantityAvailable',
                '_id': 0  # Exclude the default '_id' field
            }
        }
    ]

    # Measure the time and resources used by the query
    start_time = time.time()
    start_resources = resource.getrusage(resource.RUSAGE_SELF)

    # Execute the aggregation pipeline on the 'transactions' collection
    result = list(transactions.aggregate(pipeline_5))

    end_time = time.time()
    end_resources = resource.getrusage(resource.RUSAGE_SELF)

    # Calculate the time taken and resource utilization
    time_taken = end_time - start_time
    cpu_time_used = end_resources.ru_utime - start_resources.ru_utime
    memory_used = end_resources.ru_maxrss - start_resources.ru_maxrss

    # Print the result of the aggregation
    #for doc in result:
    #    print(doc)

    # Print the time taken and resource utilization
    print(f"Time taken for query execution: {time_taken} seconds")
    print(f"CPU time used: {cpu_time_used} seconds")
    print(f"Memory used: {memory_used} kilobytes")