import mysql.connector
import time
from sqlalchemy import create_engine
import pandas as pd
import subprocess

def sqlload_execute():
    db_config = {
        'host': 'localhost',
        'user': 'root',
        'password': '',
        'database': 'online_retail'
    }

    connection = mysql.connector.connect(**db_config)
    cursor = connection.cursor()
    engine = create_engine(
       f"mysql+mysqlconnector://{db_config['user']}:{db_config['password']}@{db_config['host']}/{db_config['database']}")


    customers_file_path = '/Users/bhoomikan/Desktop/Datawarehousing/29/customers_data.csv'
    customers_df = pd.read_csv(customers_file_path)
    print("Total Count of Customers Data: ", len(customers_df))
    init_c = time.time()
    customers_df.to_sql(name='CUSTOMER', con=engine,
                    if_exists='replace', index=False)
    end_c = time.time()
    print(f"Time taken to load the customer data file: {end_c-init_c:.2f}s\n")

    orders_file_path = '/Users/bhoomikan/Desktop/Datawarehousing/29/orders_data.csv'
    orders_df = pd.read_csv(orders_file_path)
    print("Total Count of Orders Data: ", len(orders_df))
    init_o = time.time()
    orders_df.to_sql(name='orders', con=engine, if_exists='replace', index=False)
    end_o = time.time()
    print(f"Time taken to load the orders data file: {end_o-init_o:.2f}s\n")

    products_file_path = '/Users/bhoomikan/Desktop/Datawarehousing/29/products_data.csv'
    products_df = pd.read_csv(products_file_path)
    print("Total Count of Products Data: ", len(products_df))
    init_p = time.time()
    products_df.to_sql(name='products', con=engine,
                   if_exists='replace', index=False)
    end_p = time.time()
    print(f"Time taken to load the products data file: {end_p-init_p:.2f}s\n")

    reviews_file_path = '/Users/bhoomikan/Desktop/Datawarehousing/29/reviewsdata.csv'
    reviews_df = pd.read_csv(reviews_file_path)
    print("Total Count of Reviews Data: ", len(reviews_df))
    init_r = time.time()
    reviews_df.to_sql(name='reviews', con=engine, if_exists='replace', index=False)
    end_r = time.time()
    print(f"Time taken to load the reviews data file: {end_r-init_r:.2f}s\n")


    transactions_file_path = '/Users/bhoomikan/Desktop/Datawarehousing/29/transactions_data.csv'
    transactions_df = pd.read_csv(transactions_file_path)
    print("Total Count of Transactions Data: ", len(transactions_df))
    init_t = time.time()
    transactions_df.to_sql(name='transactions', con=engine,
                       if_exists='replace', index=False)
    end_t = time.time()
    print(f"Time taken to load the transactions data file: {end_t-init_t:.2f}s\n")

# GET AVERAGE RATINGS FOR EACH PRODUCT
    query1 = "SELECT StockCode,\
    AVG(ratings) AS Ratings_Avg\
    FROM reviews\
    GROUP BY StockCode\
    ORDER BY ratings_avg DESC;"

    print(query1)

    explain_query = f"EXPLAIN {query1}"
    cursor.execute(explain_query)
    execution_plan = cursor.fetchall()
    print("Execution Plan:")
    for row in execution_plan:
        print(row)


    init_q1 = time.time()
    cursor.execute(query1)
    end_q1 = time.time()

    rows_q1 = cursor.fetchall()
    print(f"Time taken to execute the above query: {end_q1-init_q1:.2f}s\n")

    del_q="DELETE FROM TRANSACTIONS WHERE StockCode In('22752','22749','22310')"
    cursor.execute(del_q)

# GET ALL THE PRODUCTS IN THE STORE THAT HAVE NEVER BEEN SOLD TILL DATE
    query2 = "SELECT p.StockCode\
    FROM products p\
    WHERE NOT EXISTS (SELECT 1 FROM transactions t WHERE p.StockCode = t.StockCode);"

    print(query2)

    explain_query = f"EXPLAIN {query2}"
    cursor.execute(explain_query)
    execution_plan = cursor.fetchall()
    print("Execution Plan:")
    for row in execution_plan:
        print(row)

    init_q2 = time.time()
    cursor.execute(query2)
    end_q2 = time.time()

    rows_q2 = cursor.fetchall()
    print(f"Time taken to execute the above query: {end_q2-init_q2:.2f}s\n")

# GET THE DETAILS OF THE TOP 10 PRODUCTS THAT HAVE BEEN SOLD THE MOST
    query3 = "SELECT\
    r.*,\
    p.Description,\
    p.UnitPrice,\
    p.Ratings,\
    p.QuantityAvailable\
    FROM\
    (SELECT \
    StockCode,\
    count(*) as Quantity_Sold\
    FROM transactions t\
    GROUP BY StockCode\
    ORDER BY quantity_sold DESC\
    LIMIT 10) r\
    LEFT JOIN products p ON r.StockCode=p.StockCode\
    ORDER BY quantity_sold DESC;"

    print(query3)

    explain_query = f"EXPLAIN {query3}"
    cursor.execute(explain_query)
    execution_plan = cursor.fetchall()
    print("Execution Plan:")
    for row in execution_plan:
        print(row)

    init_q3 = time.time()
    cursor.execute(query3)
    end_q3 = time.time()

    rows_q3 = cursor.fetchall()
    print(f"Time taken to execute the above query: {end_q3-init_q3:.2f}s\n")

# GET ALL THOSE CUSTOMERS WHO HAVENT VISITED THE STORE FOR MORE THAN 90 DAYS
# Before Creating the Index
    query4 = "SELECT DISTINCT CustomerID,\
    DATEDIFF(CURDATE(),MAX(DATE_FORMAT(STR_TO_DATE(InvoiceDate, '%m/%d/%y %H:%i'), '%Y-%m-%d'))) as Diff_days\
    FROM\
    transactions\
    GROUP BY\
    CustomerID\
    HAVING DATEDIFF(CURDATE(),MAX(DATE_FORMAT(STR_TO_DATE(InvoiceDate, '%m/%d/%y %H:%i'), '%Y-%m-%d'))) > 90;"

    print(query4)

    explain_query = f"EXPLAIN {query4}"
    cursor.execute(explain_query)
    execution_plan = cursor.fetchall()
    print("Execution Plan:")
    for row in execution_plan:
        print(row)

    init_q4 = time.time()
    cursor.execute(query4)
    end_q4 = time.time()

    rows_q4 = cursor.fetchall()
    print(f"Time taken to execute the above query: {end_q4-init_q4:.2f}s\n")

# After Creating the Index
    createi = "CREATE INDEX idx_covering_index ON transactions (CustomerID, InvoiceDate(30));"
    cursor.execute(createi)

    query4i = "SELECT DISTINCT CustomerID,\
    DATEDIFF(CURDATE(),MAX(DATE_FORMAT(STR_TO_DATE(InvoiceDate, '%m/%d/%y %H:%i'), '%Y-%m-%d'))) as Diff_days\
    FROM\
    transactions\
    GROUP BY\
    CustomerID\
    HAVING DATEDIFF(CURDATE(),MAX(DATE_FORMAT(STR_TO_DATE(InvoiceDate, '%m/%d/%y %H:%i'), '%Y-%m-%d'))) > 90;"

    print(query4i)

    explain_query = f"EXPLAIN {query4i}"
    cursor.execute(explain_query)
    execution_plan = cursor.fetchall()
    print("Execution Plan:")
    for row in execution_plan:
        print(row)

    init_qi = time.time()
    cursor.execute(query4i)
    end_qi = time.time()

    rows_qi = cursor.fetchall()
    print(f"Time taken to execute the above query: {end_qi-init_qi:.2f}s\n")

    indexdrop = "DROP INDEX idx_covering_index ON transactions;"
    cursor.execute(indexdrop)

# GET THE TOP 10 Popular PaymentModes
    query5 = "SELECT PaymentMode,\
    count(*) as Number_Used\
    FROM orders\
    GROUP BY PaymentMode\
    ORDER BY Number_Used DESC\
    LIMIT 10;"

    print(query5)

    explain_query = f"EXPLAIN {query5}"
    cursor.execute(explain_query)
    execution_plan = cursor.fetchall()
    print("Execution Plan:")
    for row in execution_plan:
        print(row)

    init_q5 = time.time()
    cursor.execute(query5)
    end_q5 = time.time()

    rows_q5 = cursor.fetchall()
    print(f"Time taken to execute the above query: {end_q5-init_q5:.2f}s\n")

    cursor.close()
    connection.close()
