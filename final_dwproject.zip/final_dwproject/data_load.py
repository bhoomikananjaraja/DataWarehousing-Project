#1. Transactions
import random
import numpy as np
import pandas as pd
import string
from faker import Faker
from datetime import datetime, timedelta

def generate_csv():
    final_data = pd.read_csv('/Users/bhoomikan/Desktop/Datawarehousing/29/transactions.csv')
    final_data = final_data.dropna(subset = ['Description'])
    unique_customer_id = final_data['CustomerID'].unique()
    # Impute the missing values in the CustomerID
    def replace_with_random(value, array):
        if pd.isnull(value) or value==0:
            return np.random.choice(array)
        else:
            return value

# Apply the function to the desired column
#final_data['CustomerID'].replace([np.inf, -np.inf,np.nan],0, inplace=True)
    final_data['CustomerID'] = final_data['CustomerID'].apply(replace_with_random, args=(unique_customer_id,))
    final_data.dropna(subset=['CustomerID'], inplace=True)
#print(final_data.info())

# Check the uniqueness of rows
#print(len(final_data.drop_duplicates()))

# remove unique rows
    final_data = final_data.drop_duplicates()

# Recheck the uniqueness of rows
#print(len(final_data))

#print(final_data.info())

#print(final_data[final_data['CustomerID'].isnull()].head(60))
# Convert it to CSV
    final_data['InvoiceNo'] = final_data['InvoiceNo'].astype('string')
    final_data['StockCode'] = final_data['StockCode'].astype('string')
    final_data['CustomerID'] = final_data['CustomerID'].astype(float)
    final_data['CustomerID'] = final_data['CustomerID'].astype(int)
    final_data['CustomerID'] = final_data['CustomerID'].astype('string')
    final_data['Invoice_u']  = final_data['InvoiceNo'] +'_'+ final_data['StockCode']
    new_column_order = ['Invoice_u', 'InvoiceNo', 'StockCode', 'Description', 'Quantity', 'InvoiceDate', 'UnitPrice', 'CustomerID', 'Country']
    final_data = final_data[new_column_order]
    final_data.to_csv('/Users/bhoomikan/Desktop/Datawarehousing/29/transactions_data.csv', index = False)
    print(len(final_data))
    print(final_data.info())

    final_data = pd.read_csv('/Users/bhoomikan/Desktop/Datawarehousing/29/transactions_data.csv')
    products = final_data[['StockCode', 'Description', 'UnitPrice']]


    # Dropping duplicates based on 'StockCode' and keeping the first occurrence
    products['StockCode'] = products['StockCode'].astype('string')
    products['StockCode'] = products['StockCode'].str.upper()
    products_unique = products.drop_duplicates(subset='StockCode')
    products_unique['QuantityAvailable'] = np.random.randint(50, 251, size=len(products_unique))

#print(products_unique.isnull().sum())
#print(products_unique.head(15))
    data_products = products_unique
#print(len(data_products))
    unique_values = data_products['StockCode'].unique()

    for i in unique_values:
        filter_condition = final_data['StockCode'] == i
        date_min = pd.to_datetime(final_data.loc[filter_condition, 'InvoiceDate'].min())
        datetime_obj_minus_one_day = date_min - pd.Timedelta(days=1)
        datemin_val = datetime_obj_minus_one_day.date()
        data_products.loc[data_products['StockCode'] == i, 'Product_Created'] = datemin_val

        date_max = pd.to_datetime(final_data.loc[filter_condition, 'InvoiceDate'].max())
        datemax_val = date_max.date()
        data_products.loc[data_products['StockCode'] == i, 'Product_lastUpdated'] = datemax_val
        data_products['Product_Created'] = data_products['Product_Created'].apply(lambda x: np.random.choice(data_products['Product_Created'].dropna()) if pd.isna(x) else x)
        data_products['Product_lastUpdated'] = data_products['Product_Created'].apply(lambda x: np.random.choice(data_products['Product_Created'].dropna()) if pd.isna(x) else x)
    ratings = [1.0, 1.25, 1.5, 1.75, 2.0, 2.25, 2.50, 2.75, 3.0, 3.25, 3.5, 3.75, 4, 4.25, 4.50, 4.75, 5.0]
    data_products['Ratings'] = [random.choice(ratings) for i in range(len(data_products))]
    data_products.to_csv('/Users/bhoomikan/Desktop/Datawarehousing/29/products_data.csv', index = False)
    print(len(data_products))
    print(data_products.info())


    Orders = final_data[['InvoiceNo', 'InvoiceDate', 'CustomerID', 'Quantity', 'UnitPrice']]
    Orders['TotalAmount'] = Orders['Quantity'] * Orders['UnitPrice']

# Group by 'InvoiceNo' and sum the 'TotalAmount' for each group
    invoice_totals = Orders.groupby('InvoiceNo')['TotalAmount'].sum().reset_index()


# Drop duplicate 'InvoiceNo' from Orders to get unique rows
    Orders['InvoiceNo'] = Orders['InvoiceNo'].str.upper()
    Orders_unique = Orders.drop_duplicates(subset='InvoiceNo')
    print(len(Orders_unique))
# Merge the summed totals back with the unique InvoiceNo rows
    Orders_final = pd.merge(Orders_unique[['InvoiceNo', 'InvoiceDate', 'CustomerID']], 
                        invoice_totals, on='InvoiceNo')

# Round the 'TotalAmount' column to two decimal places
    Orders_final['TotalAmount'] = Orders_final['TotalAmount'].round(2)
    payment_modes = ['Credit Card', 'Debit Card', 'PayPal', 'Bank Transfer', 'Cash', 'Check', 'Mobile Payments', 'Gift Card']
    probabilities = [0.3, 0.3, 0.1, 0.1, 0.05, 0.03, 0.1, 0.02]  # Adjusted to sum to 1

# Generate the PaymentMode column
    np.random.seed(0)  # For reproducibility
    payment_mode_column = np.random.choice(payment_modes, size=len(Orders_final), p=probabilities)

# Add the PaymentMode column to the DataFrame
    Orders_final['PaymentMode'] = payment_mode_column
    Orders_final['CustomerID'] = Orders_final['CustomerID'].astype('string')
    print(Orders_final.isnull().sum())
    print(Orders_final.info())
    print(Orders_final.head(20))
    Orders_final.to_csv('/Users/bhoomikan/Desktop/Datawarehousing/29/orders_data.csv', index=False)
    print(len(Orders_final))
    print(Orders_final.info())

    Customers = final_data[['CustomerID', 'Country']]
    Customers['CustomerID'] = Customers['CustomerID'].astype(float)
    Customers['CustomerID'] = Customers['CustomerID'].astype(int)
    Customers['CustomerID'] = Customers['CustomerID'].astype('string')
    Customers['CustomerID'] = Customers['CustomerID'].str.upper()
    Customers = Customers.drop_duplicates(subset='CustomerID')


    print(Customers['CustomerID'].nunique())

# Add phone number
# List of some common US area codes
    area_codes = [202, 212, 213, 305, 310, 312, 415, 425, 503, 510, 512, 617, 619, 626, 650, 702, 718, 805, 818, 914]

# Function to generate a random US phone number with a valid area code
    def generate_us_phone_number(area_codes):
        area_code = random.choice(area_codes)
        exchange_code = random.randint(100, 999)
        subscriber_number = random.randint(1000, 9999)
        return f"({area_code}) {exchange_code}-{subscriber_number}"

    # Generate 5943 distinct phone numbers
    phone_numbers_set = set()
    while len(phone_numbers_set) < 4372:
        phone_number = generate_us_phone_number(area_codes)
        phone_numbers_set.add(phone_number)

# Convert the set to a list
    phone_numbers_list = list(phone_numbers_set)

    if len(Customers) >= 4372:
        Customers['PhoneNumber'] = phone_numbers_list
    else:
        print("Customers DataFrame has fewer rows than the number of phone numbers to be added.")

#%%
#print(Customers.head(15))



# Initialize a Faker generator
    fake = Faker()

# Generate random first and last names
    if len(Customers) >= 4372:
        Customers['FirstName'] = [fake.first_name() for _ in range(len(Customers))]
        Customers['LastName'] = [fake.last_name() for _ in range(len(Customers))]
    else:
        print("Customers DataFrame has fewer rows than the required number for name generation.")

#print(Customers.head(15))

    new_column_order = ['CustomerID', 'FirstName', 'LastName', 'PhoneNumber', 'Country']

# Reorder the columns in Customers DataFrame
    Customers = Customers[new_column_order]
#print(Customers.head(15))



    def random_date(start, end):
        """Generate a random date between `start` and `end`."""
        delta = end - start
        int_delta = (delta.days * 24 * 60 * 60) + delta.seconds
        random_second = random.randrange(int_delta)
        return start + timedelta(seconds=random_second)


    # Define the date ranges for Date_of_Birth
    dob_start = datetime(1950, 1, 1).date()
    dob_end = datetime(2000, 1, 1).date()

    # Populate Date_of_Birth
    Customers['Date_of_Birth'] = [random_date(dob_start, dob_end) for _ in range(len(Customers))]

    # Populate Gender randomly
    Customers['Gender'] = [random.choice(["Male", "Female"]) for _ in range(len(Customers))]

    # Define the date range for CustomerSince, ensuring it's at least 8 years after Date_of_Birth
    Customers['CustomerSince'] = [
        random_date(max(dob, datetime(1990, 1, 1).date()) + timedelta(days=8*365), datetime(2011, 12, 9).date()) 
        for dob in Customers['Date_of_Birth']
    ]

    new_column_order = ['CustomerID', 'FirstName', 'LastName', 'Gender', 'PhoneNumber', 'Date_of_Birth', 'CustomerSince', 'Country']
    Customers = Customers[new_column_order]
    Customers = Customers.dropna(subset='CustomerID')
    print(Customers[Customers['CustomerID'].isnull()])
    Customers.to_csv('/Users/bhoomikan/Desktop/Datawarehousing/29/customers_data.csv', index = False)
    print(len(Customers))
    print(Customers.info())




    columns_to_consider = ['StockCode', 'Description','InvoiceDate','CustomerID']
    n = 10000
    selected_df = final_data[columns_to_consider].sample(n)
    selected_df['ratings'] = [random.randint(2, 10) for i in range(len(selected_df))]
    selected_df.rename(columns={'InvoiceDate': 'ReviewDate'}, inplace=True)
    selected_df.to_csv('/Users/bhoomikan/Desktop/Datawarehousing/29/reviewsdata.csv', index=False)
    print(len(selected_df))
    print(selected_df.info())


