from data_load import generate_csv
from sqlload_execute import sqlload_execute
from loadmongo import load_mongo

def main():
    generate_csv()
    sqlload_execute()
    load_mongo()

if __name__ == "__main__":
    main()